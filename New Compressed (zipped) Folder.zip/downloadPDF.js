function downloadPDF(subject) {
    let pdfUrl = '';

    switch(subject) {
        case 'Engineering Mathematics':
            pdfUrl = 'https://drive.google.com/your_google_drive_pdf_link_for_engineering_mathematics';
            break;
        case 'Mathematical Engineering':
            pdfUrl = 'https://drive.google.com/your_google_drive_pdf_link_for_mathematical_engineering';
            break;
        case 'Computer Architecture':
            pdfUrl = 'https://drive.google.com/your_google_drive_pdf_link_for_computer_architecture';
            break;
        case 'Database Management':
            pdfUrl = 'https://drive.google.com/your_google_drive_pdf_link_for_database_management';
            break;
        case 'Network Security':
            pdfUrl = 'https://drive.google.com/your_google_drive_pdf_link_for_network_security';
            break;
        default:
            console.error('Invalid subject');
            return;
    }

    console.log('Downloading PDF:', pdfUrl);

    const anchor = document.createElement('a');
    anchor.style.display = 'none';
    anchor.href = pdfUrl;
    anchor.download = `${subject}.pdf`;

    document.body.appendChild(anchor);

    anchor.click();

    document.body.removeChild(anchor);
}
